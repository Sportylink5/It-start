
const $=(s,ctx=document)=>ctx.querySelector(s);
const $$=(s,ctx=document)=>[...ctx.querySelectorAll(s)];

function toast(message){
  const el=$("#toast");
  if(!el) return;
  el.textContent=message; el.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer=setTimeout(()=>el.classList.remove("show"),2200);
}

function markActiveNav(){
  const file=location.pathname.split("/").pop()||"index.html";
  $$("[data-nav]").forEach(a=>{
    const href=(a.getAttribute("href")||"").split("?")[0];
    a.classList.toggle("active",href===file || (file==="course.html"&&href==="courses.html") || (file==="lesson.html"&&href==="courses.html"));
  });
}

function initMobileMenu(){
  const btn=$("#menuBtn"), drawer=$("#mobileDrawer");
  if(!btn||!drawer)return;
  btn.addEventListener("click",()=>drawer.classList.toggle("show"));
  drawer.addEventListener("click",e=>{if(e.target.tagName==="A")drawer.classList.remove("show")});
}

function initTheme(){
  const b=$("#themeBtn"); if(!b)return;
  const isLight=localStorage.getItem("itstart-theme")==="light";
  if(isLight) document.body.classList.add("light-mode");
  b.addEventListener("click",()=>{
    document.body.classList.toggle("light-mode");
    localStorage.setItem("itstart-theme",document.body.classList.contains("light-mode")?"light":"dark");
    toast("Тема интерфейса изменена");
  });
}

function initCourseFilters(){
  const search=$("#courseSearch"), level=$("#levelFilter");
  if(!search||!level)return;
  const cards=$$("[data-course]");
  const apply=()=>{
    const q=search.value.trim().toLowerCase(), lv=level.value;
    cards.forEach(c=>{
      const okQ=!q || c.dataset.course.includes(q) || c.textContent.toLowerCase().includes(q);
      const okL=lv==="all" || c.dataset.level===lv;
      c.style.display=(okQ&&okL)?"":"none";
    });
  };
  search.addEventListener("input",apply); level.addEventListener("change",apply);
}

function initProgress(){
  $$("[data-progress]").forEach(el=>{
    const key=el.dataset.progress;
    const v=localStorage.getItem(key);
    if(v) el.style.width=v+"%";
  });
  $$("[data-complete]").forEach(btn=>{
    btn.addEventListener("click",()=>{
      const key=btn.dataset.complete;
      localStorage.setItem(key,"100");
      toast("Урок отмечен как пройден");
      setTimeout(()=>location.href="course.html",500);
    });
  });
}

function initEditor(){
  const editor=$("#codeEditor"), preview=$("#previewFrame"), run=$("#runCode"), reset=$("#resetCode");
  if(!editor||!preview)return;
  const initial=editor.value;
  const render=()=>{preview.srcdoc=editor.value;localStorage.setItem("itstart-lab-code",editor.value)};
  const saved=localStorage.getItem("itstart-lab-code"); if(saved) editor.value=saved;
  run?.addEventListener("click",()=>{render();toast("Код выполнен")});
  reset?.addEventListener("click",()=>{editor.value=initial;render();toast("Код сброшен")});
  render();
}

function initQuiz(){
  const btn=$("#checkQuiz"); if(!btn)return;
  btn.addEventListener("click",()=>{
    const answers={q1:"b",q2:"c",q3:"a"};
    let score=0;
    Object.entries(answers).forEach(([q,a])=>{
      const checked=$(`input[name="${q}"]:checked`);
      if(checked?.value===a)score++;
    });
    const out=$("#quizResult");
    out.className="result "+(score>=2?"ok":"bad");
    out.textContent=`Результат: ${score}/3. ${score===3?"Отлично!":score===2?"Хороший результат.":"Повтори материал урока."}`;
    localStorage.setItem("itstart-last-quiz",String(score));
  });
}

function initProfile(){
  const form=$("#profileForm");
  if(form){
    const saved=JSON.parse(localStorage.getItem("itstart-profile")||"{}");
    Object.entries(saved).forEach(([k,v])=>{if(form.elements[k])form.elements[k].value=v});
    form.addEventListener("submit",e=>{
      e.preventDefault();
      const data=Object.fromEntries(new FormData(form).entries());
      localStorage.setItem("itstart-profile",JSON.stringify(data));
      $("#profileName") && ($("#profileName").textContent=data.name||"Сергей");
      toast("Профиль сохранён");
    });
  }
}

function initAuth(){
  const form=$("#authForm"); if(!form)return;
  form.addEventListener("submit",e=>{
    e.preventDefault();
    localStorage.setItem("itstart-auth","1");
    toast("Демо-вход выполнен");
    setTimeout(()=>location.href="profile.html",500);
  });
}

document.addEventListener("DOMContentLoaded",()=>{
  markActiveNav();initMobileMenu();initTheme();initCourseFilters();initProgress();initEditor();initQuiz();initProfile();initAuth();
  initLearningRoad();initFriends();initSandbox();initAchievementsV2();initAccount();
});


function initLearningRoad(){
  const road=$("#learningRoad"); if(!road)return;
  let progress=Number(localStorage.getItem("itstart-road-progress")||4);
  const nodes=$$(".path-node",road);
  const xp=Number(localStorage.getItem("itstart-xp")||420);
  const streak=Number(localStorage.getItem("itstart-streak")||3);
  $("#xpValue") && ($("#xpValue").textContent=xp);
  $("#streakValue") && ($("#streakValue").textContent=streak);
  $("#pathProgressText") && ($("#pathProgressText").textContent=`${Math.min(progress,nodes.length)}/${nodes.length}`);
  nodes.forEach((node,i)=>{
    node.classList.remove("done","current","locked");
    const btn=$(".node-btn",node);
    if(i<progress){node.classList.add("done");btn.textContent="✓"}
    else if(i===progress){node.classList.add("current");btn.textContent="▶"}
    else{node.classList.add("locked");btn.textContent="🔒"}
    btn.addEventListener("click",()=>{
      if(i>progress){toast("Сначала пройди предыдущий урок");return}
      if(i<progress){toast("Этот этап уже пройден");return}
      const modal=$("#pathModal"); modal?.classList.add("show");
      $("#pathLessonTitle") && ($("#pathLessonTitle").textContent=node.dataset.title||"Новый урок");
    });
  });
  $("#closePathModal")?.addEventListener("click",()=>$("#pathModal")?.classList.remove("show"));
  $("#finishPathLesson")?.addEventListener("click",()=>{
    progress=Math.min(progress+1,nodes.length);
    localStorage.setItem("itstart-road-progress",String(progress));
    localStorage.setItem("itstart-xp",String(xp+25));
    $("#pathModal")?.classList.remove("show"); toast("+25 XP • Этап завершён!"); setTimeout(()=>location.reload(),450);
  });
}

function initFriends(){
  const list=$("#friendList"), form=$("#addFriendForm"); if(!list)return;
  const base=[
    {name:"AlexDev",xp:1280,online:true,avatar:"A"},{name:"MiraCode",xp:940,online:true,avatar:"M"},{name:"DenWeb",xp:710,online:false,avatar:"D"}
  ];
  let extra=JSON.parse(localStorage.getItem("itstart-friends")||"[]");
  const render=()=>{
    const all=[...base,...extra];
    list.innerHTML=all.map((f,i)=>`<div class="friend-card"><div class="friend-avatar">${(f.avatar||f.name[0]).toUpperCase()}</div><div class="friend-meta"><strong>${f.name}</strong><span class="small muted"><i class="${f.online?'online-dot':'online-dot offline-dot'}"></i>${f.online?'В сети':'Не в сети'} • ${f.xp||0} XP</span></div><div class="friend-actions"><button class="btn" data-challenge="${f.name}">Вызов</button>${i>=base.length?`<button class="icon-btn" data-remove="${i-base.length}">×</button>`:''}</div></div>`).join('');
    $$('[data-challenge]',list).forEach(b=>b.onclick=()=>toast(`Вызов для ${b.dataset.challenge} отправлен`));
    $$('[data-remove]',list).forEach(b=>b.onclick=()=>{extra.splice(Number(b.dataset.remove),1);localStorage.setItem("itstart-friends",JSON.stringify(extra));render();});
    $("#friendCount") && ($("#friendCount").textContent=all.length);
  };
  render();
  form?.addEventListener("submit",e=>{e.preventDefault();const input=$("#friendName");const name=input.value.trim();if(!name)return;extra.push({name,xp:0,online:false,avatar:name[0]});localStorage.setItem("itstart-friends",JSON.stringify(extra));input.value="";render();toast("Друг добавлен в демо-список");});
  $("#copyInvite")?.addEventListener("click",async()=>{const v=$("#inviteCode")?.value||"ITSTART-SERGEY-27";try{await navigator.clipboard.writeText(v);toast("Код приглашения скопирован")}catch{toast("Код: "+v)}});
}

function initSandbox(){
  const html=$("#sandboxHtml"),css=$("#sandboxCss"),js=$("#sandboxJs"),frame=$("#sandboxFrame"); if(!html||!css||!js||!frame)return;
  const log=$("#sandboxConsole");
  const render=()=>{
    const hook=`<script>const __send=(t)=>parent.postMessage({itstartConsole:String(t)},'*');const __old=console.log;console.log=(...a)=>{__send(a.join(' '));__old(...a)};window.onerror=(m)=>__send('ERROR: '+m);<\/script>`;
    frame.srcdoc=`<!doctype html><html><head><style>${css.value}</style></head><body>${html.value}${hook}<script>${js.value}<\/script></body></html>`;
    localStorage.setItem("itstart-sandbox-current",JSON.stringify({html:html.value,css:css.value,js:js.value}));
    if(log)log.textContent="▶ Проект запущен\n";
  };
  const saved=JSON.parse(localStorage.getItem("itstart-sandbox-current")||"null");
  if(saved){html.value=saved.html??html.value;css.value=saved.css??css.value;js.value=saved.js??js.value}
  $$("[data-sandbox-tab]").forEach(tab=>tab.addEventListener("click",()=>{$$("[data-sandbox-tab]").forEach(x=>x.classList.remove("active"));$$('.sandbox-code').forEach(x=>x.classList.remove('active'));tab.classList.add('active');$("#sandbox"+tab.dataset.sandboxTab)?.classList.add('active');}));
  $("#sandboxRun")?.addEventListener("click",()=>{render();toast("Код запущен")});
  $("#sandboxReset")?.addEventListener("click",()=>{localStorage.removeItem("itstart-sandbox-current");location.reload()});
  window.addEventListener("message",e=>{if(e.data?.itstartConsole&&log)log.textContent+=e.data.itstartConsole+"\n"});
  const refreshProjects=()=>{const box=$("#savedProjects");if(!box)return;const ps=JSON.parse(localStorage.getItem("itstart-sandbox-projects")||"{}");box.innerHTML=Object.keys(ps).map(n=>`<button class="project-chip" data-project="${n}">${n}</button>`).join('')||'<span class="muted small">Сохранённых проектов пока нет</span>';$$('[data-project]',box).forEach(b=>b.onclick=()=>{const p=ps[b.dataset.project];html.value=p.html;css.value=p.css;js.value=p.js;$("#projectName").value=b.dataset.project;render();toast("Проект загружен")});};
  $("#saveProject")?.addEventListener("click",()=>{const n=$("#projectName")?.value.trim()||"Мой проект";const ps=JSON.parse(localStorage.getItem("itstart-sandbox-projects")||"{}");ps[n]={html:html.value,css:css.value,js:js.value};localStorage.setItem("itstart-sandbox-projects",JSON.stringify(ps));refreshProjects();toast("Проект сохранён")});
  $("#deleteProject")?.addEventListener("click",()=>{const n=$("#projectName")?.value.trim();if(!n)return;const ps=JSON.parse(localStorage.getItem("itstart-sandbox-projects")||"{}");delete ps[n];localStorage.setItem("itstart-sandbox-projects",JSON.stringify(ps));refreshProjects();toast("Проект удалён")});
  refreshProjects();render();
}

function initAchievementsV2(){
  const grid=$("#achievementGrid"); if(!grid)return;
  const road=Number(localStorage.getItem("itstart-road-progress")||4), quiz=Number(localStorage.getItem("itstart-last-quiz")||0), xp=Number(localStorage.getItem("itstart-xp")||420), projects=Object.keys(JSON.parse(localStorage.getItem("itstart-sandbox-projects")||"{}")).length;
  const values={road,quiz,xp,projects,friends:3+JSON.parse(localStorage.getItem("itstart-friends")||"[]").length};
  $$('[data-ach]',grid).forEach(card=>{const key=card.dataset.ach,need=Number(card.dataset.need||1),v=Number(values[key]||0),pct=Math.min(100,Math.round(v/need*100));$(".ach-progress span",card)?.style.setProperty('width',pct+'%');$("[data-ach-text]",card) && ($("[data-ach-text]",card).textContent=`${Math.min(v,need)}/${need}`);card.classList.toggle('unlocked',v>=need);card.classList.toggle('locked',v<need)});
  const unlocked=$$('.achievement-card.unlocked',grid).length;$("#unlockedCount") && ($("#unlockedCount").textContent=unlocked);
}

function initAccount(){
  if(!$("#accountPage"))return;
  const p=JSON.parse(localStorage.getItem("itstart-profile")||"{}");
  $("#accountName") && ($("#accountName").textContent=p.name||"Сергей");
  $("#accountEmail") && ($("#accountEmail").textContent=p.email||"student@example.com");
  $("#accountXP") && ($("#accountXP").textContent=localStorage.getItem("itstart-xp")||"420");
  $$('[data-demo-action]').forEach(b=>b.onclick=()=>toast(b.dataset.demoAction));
}
